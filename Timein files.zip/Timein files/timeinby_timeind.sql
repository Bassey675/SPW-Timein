-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 22, 2020 at 04:51 PM
-- Server version: 5.6.47-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timeinby_timeind`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendarevents`
--

CREATE TABLE `calendarevents` (
  `eventId` int(5) NOT NULL,
  `empId` int(5) NOT NULL DEFAULT '0',
  `isAdmin` int(1) NOT NULL DEFAULT '0',
  `isShared` int(1) NOT NULL DEFAULT '0',
  `isPublic` int(1) NOT NULL DEFAULT '0',
  `startDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `endDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `eventTitle` varchar(50) CHARACTER SET utf8 NOT NULL,
  `eventDesc` text COLLATE utf8_bin
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `calendarevents`
--

INSERT INTO `calendarevents` (`eventId`, `empId`, `isAdmin`, `isShared`, `isPublic`, `startDate`, `endDate`, `eventTitle`, `eventDesc`) VALUES
(1, 3, 0, 0, 0, '2020-03-30 23:00:00', '2020-03-30 23:00:00', 'Task: signing files', 'sign it '),
(2, 10, 0, 0, 0, '2020-04-11 00:00:00', '2020-04-11 21:00:00', 'Task: Signing the files', 'signing the pps files '),
(4, 4, 1, 0, 0, '2020-04-29 23:00:00', '2020-04-29 23:00:00', 'Task: signing files', 'Complete the signing of Cyber-security students files.');

-- --------------------------------------------------------

--
-- Table structure for table `compiled`
--

CREATE TABLE `compiled` (
  `compileId` int(5) NOT NULL,
  `compliedBy` int(5) NOT NULL,
  `weekNo` int(2) UNSIGNED ZEROFILL NOT NULL,
  `clockYear` int(4) NOT NULL,
  `dateComplied` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `compiled`
--

INSERT INTO `compiled` (`compileId`, `compliedBy`, `weekNo`, `clockYear`, `dateComplied`) VALUES
(1, 2, 14, 2020, '2020-04-10 21:14:37'),
(2, 2, 16, 2020, '2020-04-16 21:40:28');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `docId` int(5) NOT NULL,
  `empId` int(5) NOT NULL,
  `docName` varchar(255) COLLATE utf8_bin NOT NULL,
  `docDesc` longtext COLLATE utf8_bin NOT NULL,
  `docUrl` varchar(255) COLLATE utf8_bin NOT NULL,
  `docDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`docId`, `empId`, `docName`, `docDesc`, `docUrl`, `docDate`) VALUES
(1, 2, 'report', 'report', 'report-d6963a7b.docx', '2020-04-10 21:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `empId` int(5) NOT NULL,
  `isAdmin` int(1) NOT NULL DEFAULT '0',
  `isMgr` int(1) NOT NULL DEFAULT '0',
  `empEmail` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `empFirst` varchar(255) CHARACTER SET utf8 NOT NULL,
  `empMiddleInt` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `empLast` varchar(255) CHARACTER SET utf8 NOT NULL,
  `empDob` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `empSsn` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empAvatar` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT 'empAvatar.png',
  `empPhone1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empPhone2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empPhone3` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empAddress1` text COLLATE utf8_bin,
  `empAddress2` text COLLATE utf8_bin,
  `empPosition` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `empPayGrade` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empStartSalery` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empStartHourly` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empCurrSalery` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empCurrHourly` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `empSalaryTerm` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT 'Year',
  `leaveHours` int(3) NOT NULL DEFAULT '0',
  `empHireDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isActive` int(1) NOT NULL DEFAULT '0',
  `empLastVisited` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `empTerminationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `terminationReason` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`empId`, `isAdmin`, `isMgr`, `empEmail`, `password`, `empFirst`, `empMiddleInt`, `empLast`, `empDob`, `empSsn`, `empAvatar`, `empPhone1`, `empPhone2`, `empPhone3`, `empAddress1`, `empAddress2`, `empPosition`, `empPayGrade`, `empStartSalery`, `empStartHourly`, `empCurrSalery`, `empCurrHourly`, `empSalaryTerm`, `leaveHours`, `empHireDate`, `isActive`, `empLastVisited`, `empTerminationDate`, `terminationReason`) VALUES
(10, 0, 0, 'udy@gmail.com', '$2y$10$2O1IAr43JyUNKEBwuLc6ZuK4dzJFTbYpPWG4H2HgkAQG2cxekgXVi', 'udy', '', 'mag', '0000-00-00 00:00:00', NULL, 'udy_mag_816545.jpg', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Year', 0, '2020-03-31 23:00:00', 1, '2020-04-16 21:31:51', '0000-00-00 00:00:00', NULL),
(4, 0, 1, 'jp123@gmail.com', '$2y$10$nyqrz7RU.Iy0c0GKLQzi/.1CnsHsxVic9FwgwtWPoCDPdH8rE7mUi', 'john', '', 'paul', '0000-00-00 00:00:00', NULL, 'john_paul_160301.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Year', 0, '2020-03-31 23:00:00', 1, '2020-04-18 05:18:57', '0000-00-00 00:00:00', NULL),
(14, 0, 0, 'johnchigozie37@yahoo.com', '$2y$10$GIgJFQgxMHTZjgiZxejl8OSxlJxWCaQXP.3QVXGWppmWBtgHF6pzm', 'alex', '', 'cooks', '0000-00-00 00:00:00', NULL, 'empAvatar.png', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Year', 0, '2020-04-01 04:00:00', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(18, 1, 1, 'piblaze1988@gmail.com', '$2y$10$93N/ODigoJVeqLAZsQS8SuGogtJ32zF3Uio4eguRTeA9zMZq4B5c2', 'Bassey', '', 'Bassey', '0000-00-00 00:00:00', NULL, 'bassey_bassey_151987.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Year', 0, '2020-04-30 04:00:00', 1, '2020-04-22 20:44:07', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `emptasks`
--

CREATE TABLE `emptasks` (
  `empTaskId` int(5) NOT NULL,
  `assignedTo` int(5) NOT NULL DEFAULT '0',
  `createdBy` int(5) NOT NULL DEFAULT '0',
  `taskTitle` varchar(50) COLLATE utf8_bin NOT NULL,
  `taskDesc` longtext COLLATE utf8_bin NOT NULL,
  `taskNotes` longtext COLLATE utf8_bin,
  `taskPriority` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `taskStatus` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `taskStart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `taskDue` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isClosed` int(1) NOT NULL DEFAULT '0',
  `dateClosed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `emptasks`
--

INSERT INTO `emptasks` (`empTaskId`, `assignedTo`, `createdBy`, `taskTitle`, `taskDesc`, `taskNotes`, `taskPriority`, `taskStatus`, `taskStart`, `taskDue`, `isClosed`, `dateClosed`) VALUES
(1, 3, 3, 'signing files', 'sign it ', NULL, 'high', 'Closed', '2020-03-31 14:37:22', '2020-03-30 23:00:00', 1, '2020-03-31 14:39:51'),
(2, 10, 10, 'Signing the files', 'signing the pps files ', '', 'High', 'Closed', '2020-04-10 20:56:05', '2020-04-10 23:00:00', 1, '2020-04-10 21:04:53'),
(3, 4, 4, 'signing files', 'Complete the signing of Cyber-security students files.', NULL, 'high', 'undone', '2020-04-16 21:48:32', '2020-04-29 23:00:00', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `leaveearned`
--

CREATE TABLE `leaveearned` (
  `earnedId` int(5) NOT NULL,
  `empId` int(5) NOT NULL DEFAULT '0',
  `weekNo` int(2) UNSIGNED ZEROFILL NOT NULL,
  `clockYear` int(4) NOT NULL,
  `leaveHours` decimal(3,1) NOT NULL DEFAULT '0.0',
  `dateEntered` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `leaveearned`
--

INSERT INTO `leaveearned` (`earnedId`, `empId`, `weekNo`, `clockYear`, `leaveHours`, `dateEntered`) VALUES
(1, 3, 01, 2020, 2.0, '2020-04-01 11:34:05'),
(2, 4, 02, 2020, 60.0, '2020-04-10 20:50:28'),
(3, 2, 14, 2020, 0.0, '2020-04-10 21:14:37'),
(4, 10, 14, 2020, 0.0, '2020-04-10 21:14:37'),
(5, 4, 14, 2020, 0.0, '2020-04-10 21:14:37'),
(6, 2, 16, 2020, 0.0, '2020-04-16 21:40:28'),
(7, 10, 16, 2020, 0.0, '2020-04-16 21:40:28'),
(8, 4, 16, 2020, 0.0, '2020-04-16 21:40:28'),
(9, 4, 16, 2020, 2.0, '2020-04-16 21:46:37');

-- --------------------------------------------------------

--
-- Table structure for table `leavetaken`
--

CREATE TABLE `leavetaken` (
  `takenId` int(5) NOT NULL,
  `empId` int(5) NOT NULL DEFAULT '0',
  `clockYear` int(4) NOT NULL,
  `hoursTaken` decimal(3,1) NOT NULL DEFAULT '0.0',
  `dateEntered` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `leavetaken`
--

INSERT INTO `leavetaken` (`takenId`, `empId`, `clockYear`, `hoursTaken`, `dateEntered`) VALUES
(1, 4, 2020, 12.0, '2020-04-10 20:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `noticeId` int(5) NOT NULL,
  `createdBy` int(5) NOT NULL DEFAULT '0',
  `isActive` int(1) NOT NULL DEFAULT '1',
  `noticeTitle` varchar(255) COLLATE utf8_bin NOT NULL,
  `noticeText` longtext COLLATE utf8_bin NOT NULL,
  `noticeDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `noticeStart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `noticeExpires` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `privatemessages`
--

CREATE TABLE `privatemessages` (
  `messageId` int(5) NOT NULL,
  `fromId` int(5) NOT NULL DEFAULT '0',
  `toId` int(5) NOT NULL,
  `origId` int(5) NOT NULL DEFAULT '0',
  `messageTitle` varchar(50) CHARACTER SET utf8 NOT NULL,
  `messageText` text COLLATE utf8_bin,
  `messageDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `toRead` int(1) NOT NULL DEFAULT '0',
  `toArchived` int(1) NOT NULL DEFAULT '0',
  `toDeleted` int(1) NOT NULL DEFAULT '0',
  `fromDeleted` int(1) NOT NULL DEFAULT '0',
  `lastUpdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `privatemessages`
--

INSERT INTO `privatemessages` (`messageId`, `fromId`, `toId`, `origId`, `messageTitle`, `messageText`, `messageDate`, `toRead`, `toArchived`, `toDeleted`, `fromDeleted`, `lastUpdated`) VALUES
(1, 3, 2, 0, 'system error', 'hi check my system', '2020-03-31 14:41:10', 1, 0, 0, 0, '0000-00-00 00:00:00'),
(2, 3, 2, 0, 'system error', 'system failure', '2020-03-31 14:41:51', 1, 0, 0, 0, '0000-00-00 00:00:00'),
(3, 2, 3, 1, 're: system error', 'PHP is easy to learn and use language. Programmers can go through multiple PHP tutorials available online. Many people learn PHP due to the immense number of websites that use the language. Over 75 percent of the top 10 million websites use PHP, making it a must-learn a language for web developers. Moreover, PHP has a large community online that can help you take your skills to the next level. PHP has the third-largest StackOverflow Community, the fifth-largest Meetup Community and it is the fifth most popular language on GitHub. The interest in PHP is still alive, and its pool of features are inspiring more and more people to learn PHP.', '2020-03-31 14:54:02', 1, 0, 0, 0, '0000-00-00 00:00:00'),
(4, 2, 10, 0, 'dddd', 'ddd', '2020-04-16 21:00:29', 0, 0, 0, 0, '0000-00-00 00:00:00'),
(5, 2, 4, 0, 'ddd', 'ddd', '2020-04-16 21:00:42', 0, 0, 0, 0, '0000-00-00 00:00:00'),
(6, 2, 4, 0, 'ddd', 'ddd', '2020-04-16 21:00:48', 0, 0, 0, 0, '0000-00-00 00:00:00'),
(7, 2, 11, 0, 'Welcome!', 'Welcome to timeIn please log in and change your password', '2020-04-17 17:15:19', 0, 0, 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sitesettings`
--

CREATE TABLE `sitesettings` (
  `installUrl` varchar(100) COLLATE utf8_bin NOT NULL,
  `localization` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'en',
  `siteName` varchar(255) COLLATE utf8_bin NOT NULL,
  `businessName` varchar(255) COLLATE utf8_bin NOT NULL,
  `businessAddress` longtext COLLATE utf8_bin,
  `businessEmail` varchar(255) COLLATE utf8_bin NOT NULL,
  `businessPhone1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `businessPhone2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uploadPath` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'uploads/',
  `businessDocs` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'documents/',
  `fileTypesAllowed` varchar(255) COLLATE utf8_bin NOT NULL,
  `avatarFolder` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'avatars/',
  `avatarTypes` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'jpg,png,svg',
  `allowRegistrations` int(1) NOT NULL DEFAULT '0',
  `enableTimeEdits` int(1) NOT NULL DEFAULT '0',
  `enablePii` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sitesettings`
--

INSERT INTO `sitesettings` (`installUrl`, `localization`, `siteName`, `businessName`, `businessAddress`, `businessEmail`, `businessPhone1`, `businessPhone2`, `uploadPath`, `businessDocs`, `fileTypesAllowed`, `avatarFolder`, `avatarTypes`, `allowRegistrations`, `enableTimeEdits`, `enablePii`) VALUES
('http://localhost/timein/', 'en', 'bbtimein', 'bb', 'parkgate', 'piblaze1988@gmail.com', '', '', 'uploads/', 'documents/', 'gif,jpg,jpeg,png,tiff,tif,zip,rar,pdf,doc,docx,txt,xls,csv', 'avatars/', 'jpg,jpeg,png,svg', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `timeclock`
--

CREATE TABLE `timeclock` (
  `clockId` int(5) NOT NULL,
  `empId` int(5) NOT NULL DEFAULT '0',
  `weekNo` int(2) UNSIGNED ZEROFILL NOT NULL,
  `clockYear` int(4) NOT NULL,
  `running` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `timeclock`
--

INSERT INTO `timeclock` (`clockId`, `empId`, `weekNo`, `clockYear`, `running`) VALUES
(1, 2, 14, 2020, 0),
(2, 3, 14, 2020, 1),
(3, 4, 16, 2020, 0),
(4, 10, 16, 2020, 1);

-- --------------------------------------------------------

--
-- Table structure for table `timeedits`
--

CREATE TABLE `timeedits` (
  `editId` int(5) NOT NULL,
  `entryId` int(5) NOT NULL,
  `editedBy` int(5) NOT NULL,
  `editedDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `origStartTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `origEndTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editedStartTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editedEndTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editReason` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `timeentry`
--

CREATE TABLE `timeentry` (
  `entryId` int(5) NOT NULL,
  `clockId` int(5) NOT NULL,
  `empId` int(5) NOT NULL DEFAULT '0',
  `entryDate` date NOT NULL DEFAULT '0000-00-00',
  `startTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `endTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `entryType` int(5) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `timeentry`
--

INSERT INTO `timeentry` (`entryId`, `clockId`, `empId`, `entryDate`, `startTime`, `endTime`, `entryType`) VALUES
(1, 1, 2, '2020-03-31', '2020-03-31 14:15:50', '2020-03-31 14:33:57', 1),
(2, 2, 3, '2020-03-31', '2020-03-31 14:37:42', '2020-03-31 14:56:40', 1),
(3, 2, 3, '2020-03-31', '2020-03-31 14:56:57', '2020-03-31 14:57:01', 1),
(4, 2, 3, '2020-03-31', '2020-03-31 14:57:04', '2020-03-31 14:57:08', 1),
(5, 2, 3, '2020-04-01', '2020-04-01 11:29:17', '0000-00-00 00:00:00', 1),
(6, 3, 4, '2020-04-15', '2020-04-15 14:52:59', '2020-04-15 14:53:00', 1),
(7, 4, 10, '2020-04-15', '2020-04-15 14:53:09', '2020-04-15 14:53:10', 1),
(8, 3, 4, '2020-04-16', '2020-04-16 21:16:16', '2020-04-16 21:21:59', 1),
(9, 3, 4, '2020-04-16', '2020-04-16 21:27:27', '2020-04-16 21:29:21', 1),
(10, 4, 10, '2020-04-16', '2020-04-16 21:31:53', '0000-00-00 00:00:00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendarevents`
--
ALTER TABLE `calendarevents`
  ADD PRIMARY KEY (`eventId`);

--
-- Indexes for table `compiled`
--
ALTER TABLE `compiled`
  ADD PRIMARY KEY (`compileId`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`docId`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`empId`);

--
-- Indexes for table `emptasks`
--
ALTER TABLE `emptasks`
  ADD PRIMARY KEY (`empTaskId`);

--
-- Indexes for table `leaveearned`
--
ALTER TABLE `leaveearned`
  ADD PRIMARY KEY (`earnedId`);

--
-- Indexes for table `leavetaken`
--
ALTER TABLE `leavetaken`
  ADD PRIMARY KEY (`takenId`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`noticeId`);

--
-- Indexes for table `privatemessages`
--
ALTER TABLE `privatemessages`
  ADD PRIMARY KEY (`messageId`);

--
-- Indexes for table `sitesettings`
--
ALTER TABLE `sitesettings`
  ADD PRIMARY KEY (`installUrl`);

--
-- Indexes for table `timeclock`
--
ALTER TABLE `timeclock`
  ADD PRIMARY KEY (`clockId`);

--
-- Indexes for table `timeedits`
--
ALTER TABLE `timeedits`
  ADD PRIMARY KEY (`editId`);

--
-- Indexes for table `timeentry`
--
ALTER TABLE `timeentry`
  ADD PRIMARY KEY (`entryId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calendarevents`
--
ALTER TABLE `calendarevents`
  MODIFY `eventId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `compiled`
--
ALTER TABLE `compiled`
  MODIFY `compileId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `docId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `empId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `emptasks`
--
ALTER TABLE `emptasks`
  MODIFY `empTaskId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaveearned`
--
ALTER TABLE `leaveearned`
  MODIFY `earnedId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `leavetaken`
--
ALTER TABLE `leavetaken`
  MODIFY `takenId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `noticeId` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privatemessages`
--
ALTER TABLE `privatemessages`
  MODIFY `messageId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `timeclock`
--
ALTER TABLE `timeclock`
  MODIFY `clockId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `timeedits`
--
ALTER TABLE `timeedits`
  MODIFY `editId` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timeentry`
--
ALTER TABLE `timeentry`
  MODIFY `entryId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
