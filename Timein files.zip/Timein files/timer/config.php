<?php
header("X-XSS-Protection: 1; mode=block");
header("X-Frame-Options: sameorigin");
header("X-Content-Type-Options: nosniff");
header("Strict-Transport-Security: max-age=15768000");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Expect-CT: max-age=7776000, enforce");
header("X-Permitted-Cross-Domain-Policies: none");
error_reporting(0);
ini_set('display_errors', '0');
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);

// date_default_timezone_set('Europe/Dublin');

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'timerdb';

//Connect
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if (mysqli_connect_errno()) {
	printf("MySQLi connection failed: ", mysqli_connect_error());
	exit();
}

// Change character set to utf8
if (!$mysqli->set_charset('utf8')) {
	printf('Error loading character set utf8: %s\n', $mysqli->error);
}
?>