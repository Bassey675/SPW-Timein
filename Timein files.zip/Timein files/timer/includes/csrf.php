<?php

abstract class CSRF
{
	const SESSION_NAME = 'nomedosite_csrf_token';
	const FIELD_NAME = 'nomedosite_csrf_check';

	private static function set_session()
	{
		if (!isset($_SESSION[self::SESSION_NAME]))
		{
			$_SESSION[self::SESSION_NAME] = uniqid(rand(1000, 9999), true);
		}
	}

	public static function check()
	{
		self::set_session();

		if (!isset($_POST[self::FIELD_NAME]) || $_POST[self::FIELD_NAME] != $_SESSION[self::SESSION_NAME])
		{
			header('HTTP/1.1 403 Forbidden');
			exit('<h1>Forbidden</h1>');
		}
	}

	public static function token($input = true)
	{
		self::set_session();

		if ($input)
			echo '<input type="hidden" name="' . self::FIELD_NAME . '" value="';

		echo $_SESSION[self::SESSION_NAME];

		if ($input)
			echo '" />';
	}
}